package com.example.bridge

import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.concurrent.TimeUnit

private const val UA = "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0"

class OkDownloader : Downloader() {
    private val client = OkHttpClient.Builder().readTimeout(30, TimeUnit.SECONDS).build()

    override fun execute(request: Request): Response {
        val method = request.httpMethod()
        val data = request.dataToSend()
        val body = when {
            data != null -> data.toRequestBody()
            method == "POST" -> ByteArray(0).toRequestBody()
            else -> null
        }
        val b = okhttp3.Request.Builder().method(method, body).url(request.url())
            .header("User-Agent", UA)
        request.headers().forEach { (k, vals) ->
            b.removeHeader(k)
            vals.forEach { b.addHeader(k, it) }
        }
        client.newCall(b.build()).execute().use { r ->
            if (r.code == 429) throw ReCaptchaException("reCaptcha", request.url())
            return Response(r.code, r.message, r.headers.toMultimap(),
                r.body?.string(), r.request.url.toString())
        }
    }
}

object YouTube {
    private val urlCache = HashMap<String, String>()

    @Synchronized private fun init() {
        if (NewPipe.getDownloader() == null) NewPipe.init(OkDownloader())
    }

    fun search(query: String): JSONArray {
        init()
        val yt = ServiceList.YouTube
        val q = yt.searchQHFactory.fromQuery(query,
            listOf(YoutubeSearchQueryHandlerFactory.VIDEOS), "")
        val items = SearchInfo.getInfo(yt, q).relatedItems
        val arr = JSONArray()
        for (it in items.filterIsInstance<StreamInfoItem>().take(15)) {
            val id = it.url.substringAfter("v=").substringBefore("&")
            val d = it.duration
            arr.put(JSONObject().put("id", id).put("title", it.name)
                .put("channel", it.uploaderName ?: "")
                .put("duration", if (d > 0) "%d:%02d".format(d / 60, d % 60) else "canlı"))
        }
        return arr
    }

    /** Muxed (ses+görüntü) MP4 progressive akış; Galaxy Wonder için en düşük çözünürlük tercih edilir. */
    @Synchronized fun streamUrl(id: String): String {
        urlCache[id]?.let { return it }
        init()
        val info = StreamInfo.getInfo(ServiceList.YouTube, "https://www.youtube.com/watch?v=$id")
        val s = info.videoStreams.filter { it.format == MediaFormat.MPEG_4 }
            .minByOrNull { it.resolution.filter(Char::isDigit).toIntOrNull() ?: 9999 }
            ?: info.videoStreams.firstOrNull()
            ?: throw IllegalStateException("Oynatılabilir akış bulunamadı")
        urlCache[id] = s.content
        return s.content
    }

    fun invalidate(id: String) { synchronized(this) { urlCache.remove(id) } }
}
