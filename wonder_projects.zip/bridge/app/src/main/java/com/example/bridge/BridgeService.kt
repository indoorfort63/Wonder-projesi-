package com.example.bridge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager

class BridgeService : Service() {
    companion object {
        const val PORT = 8080
        @Volatile var running = false
    }

    private var server: BridgeServer? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("bridge", "Bridge", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bridge")
            .setContentTitle("Wonder Bridge çalışıyor")
            .setContentText("Port $PORT dinleniyor")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .build()
        startForeground(1, n)

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bridge:wake").apply { acquire() }
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "bridge:wifi").apply { acquire() }

        if (server == null) {
            server = BridgeServer(this, PORT).also { it.start() }
            running = true
        }
        return START_STICKY
    }

    override fun onDestroy() {
        server?.stop(); server = null; running = false
        wake?.let { if (it.isHeld) it.release() }
        wifi?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
