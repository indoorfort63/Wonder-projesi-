package com.example.bridge

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.format.Formatter
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var toggle: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        info = findViewById(R.id.info)
        toggle = findViewById(R.id.toggle)
        val key = findViewById<EditText>(R.id.key)
        val prefs = getSharedPreferences("bridge", MODE_PRIVATE)
        if (!prefs.getString("gemini_key", "").isNullOrEmpty()) key.hint = "Anahtar kayıtlı (değiştirmek için yaz)"

        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        findViewById<Button>(R.id.saveKey).setOnClickListener {
            prefs.edit().putString("gemini_key", key.text.toString().trim()).apply()
            key.setText("")
            Toast.makeText(this, "Kaydedildi", Toast.LENGTH_SHORT).show()
        }
        toggle.setOnClickListener {
            val i = Intent(this, BridgeService::class.java)
            if (BridgeService.running) stopService(i) else startForegroundService(i)
            toggle.postDelayed({ refresh() }, 500)
        }
        findViewById<Button>(R.id.battery).setOnClickListener {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isIgnoringBatteryOptimizations(packageName)) {
                Toast.makeText(this, "Zaten muaf", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")))
            }
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    @Suppress("DEPRECATION")
    private fun refresh() {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ip = Formatter.formatIpAddress(wm.connectionInfo.ipAddress)
        info.text = "Durum: " + (if (BridgeService.running) "ÇALIŞIYOR" else "Durdu") +
                "\nBu cihazın IP adresi: $ip\nPort: ${BridgeService.PORT}\n" +
                "Client'a şunu gir: $ip : ${BridgeService.PORT}"
        toggle.text = if (BridgeService.running) "Köprüyü Durdur" else "Köprüyü Başlat"
    }
}
