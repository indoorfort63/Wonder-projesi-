package com.example.bridge

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class Gemini(private val ctx: Context) {
    private val history = ArrayList<Pair<String, String>>()
    private val endpoint =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"

    @Synchronized fun reset() = history.clear()

    @Synchronized fun chat(msg: String): String {
        val key = ctx.getSharedPreferences("bridge", Context.MODE_PRIVATE)
            .getString("gemini_key", "") ?: ""
        if (key.isBlank()) throw IOException("Bridge uygulamasında Gemini anahtarı girilmemiş")

        history.add("user" to msg)
        while (history.size > 20) history.removeAt(0)
        val contents = JSONArray()
        for ((role, text) in history) {
            contents.put(JSONObject().put("role", role)
                .put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        val body = JSONObject().put("contents", contents).toString()

        try {
            val c = URL(endpoint).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            val text = (if (code < 400) c.inputStream else c.errorStream)
                .bufferedReader().use { it.readText() }
            if (code >= 400) throw IOException("Gemini $code: ${text.take(300)}")
            val reply = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            history.add("model" to reply)
            return reply
        } catch (e: Exception) {
            history.removeAt(history.size - 1)
            throw e
        }
    }
}
