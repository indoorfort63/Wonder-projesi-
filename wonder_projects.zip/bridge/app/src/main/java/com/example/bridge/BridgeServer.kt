package com.example.bridge

import android.content.Context
import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL

class BridgeServer(ctx: Context, port: Int) : NanoHTTPD(port) {
    private val gemini = Gemini(ctx)

    private fun json(o: JSONObject, st: Response.IStatus = Response.Status.OK): Response =
        newFixedLengthResponse(st, "application/json; charset=utf-8", o.toString())

    override fun serve(session: IHTTPSession): Response {
        return try {
            when (session.uri) {
                "/ping" -> json(JSONObject().put("status", "ok"))
                "/reset" -> { gemini.reset(); json(JSONObject().put("status", "reset")) }
                "/chat" -> {
                    val files = HashMap<String, String>()
                    session.parseBody(files)
                    val msg = JSONObject(files["postData"] ?: "{}").optString("message")
                    json(JSONObject().put("reply", gemini.chat(msg)))
                }
                "/search" -> {
                    val q = session.parms["q"] ?: ""
                    json(JSONObject().put("results", YouTube.search(q)))
                }
                "/thumb" -> {
                    val id = session.parms["id"] ?: ""
                    val bytes = URL("https://i.ytimg.com/vi/$id/default.jpg").readBytes()
                    newFixedLengthResponse(Response.Status.OK, "image/jpeg",
                        ByteArrayInputStream(bytes), bytes.size.toLong())
                }
                "/video" -> serveVideo(session)
                else -> json(JSONObject().put("error", "not found"), Response.Status.NOT_FOUND)
            }
        } catch (e: Exception) {
            json(JSONObject().put("error", e.message ?: e.toString()),
                Response.Status.INTERNAL_ERROR)
        }
    }

    /** googlevideo HTTPS akışını Range desteğiyle düz HTTP olarak Client'a aktarır. */
    private fun serveVideo(session: IHTTPSession): Response {
        val id = session.parms["id"] ?: throw IllegalArgumentException("id yok")
        val range = session.headers["range"]
        var conn = open(YouTube.streamUrl(id), range)
        if (conn.responseCode >= 400) {          // süresi dolmuş link olabilir, yeniden çöz
            YouTube.invalidate(id)
            conn = open(YouTube.streamUrl(id), range)
        }
        val code = conn.responseCode
        val st = if (code == 206) Response.Status.PARTIAL_CONTENT else Response.Status.OK
        val len = conn.getHeaderField("Content-Length")?.toLongOrNull() ?: -1L
        val r = if (len >= 0)
            newFixedLengthResponse(st, "video/mp4", conn.inputStream, len)
        else newChunkedResponse(st, "video/mp4", conn.inputStream)
        conn.getHeaderField("Content-Range")?.let { r.addHeader("Content-Range", it) }
        r.addHeader("Accept-Ranges", "bytes")
        return r
    }

    private fun open(url: String, range: String?): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        if (range != null) c.setRequestProperty("Range", range)
        return c
    }
}
